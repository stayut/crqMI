library(crqMI)
load("data/simdata.RData")
tau=c(0.1,0.2,0.25,0.3,0.4,0.5,0.6)
Boostrap=F;
if(Boostrap){pos.boot=pt.boot=c()}
imp="logY"#user-specified imputation model imp="noY" or imp="nonlinear"
pi.fam0="logistic" #or "probit"
est.list=list();vtemp.list=list();SE.list=list()

for(time.sim in 1:length(datasim.list)){
  print(time.sim)
  datasim= datasim.list[[time.sim]]
  obs.data = datasim$obs.data
  Y = obs.data$Y  # censored outcomes
  Z = obs.data$Z  # censored covariates
  X = obs.data$X # fully-observed covariates
  delta.v =obs.data$delta.v # censoring indicator for censored covariate
  delta.t =obs.data$delta.t # censoring indicator for censored outcomes
  d = datasim$d  # detection limits for censored covariates
  ctype= datasim$ctype

  if(imp=="logY"){
    Imp0=NULL
  }else if(imp=="noY"){
    Imp0=X
  }else if(imp=="nonlinear"){
    logy.point= seq(min(log(Y)),max(log(Y)),length.out = n)
    bspline.logy= bs(logy.point,df=3) #,degree=?
    bs.logy= as.matrix(data.frame(predict(bspline.logy,log(Y))))
    x1.point= seq(min(X[,1]),max(X[,1]),length.out = n)
    bspline.x1= bs(x1.point,df=3) #,degree=?
    bs.x1= as.matrix(data.frame(predict(bspline.x1,X[,1])))
    Imp0= cbind(bs.logy, delta.t,bs.x1, X[,2])
  }

  out=crqMI.nose(Y, Z, X, d, delta.v, delta.t,  Imp=Imp0,
            M = 10, tau=tau, ctype=ctype,seed=T, pi.fam=pi.fam0)


  trueV=coef(crq(Surv(log(Y), delta.t) ~  datasim$true.data$V + X,
                 method="PengHuang"),taus=tau)
  colnames(trueV)=paste0("trueV.tau=",tau)
  est.list[[time.sim]]=cbind(trueV,out)

  if(Boostrap){
    out.boot=try(suppressWarnings(crqMI.boot(Y, Z, X, d, delta.v, delta.t,
                                             Imp=Imp0, M = 10, tau=tau, ctype=ctype,
                                             Boot=Boot,seed=T,pi.fam=pi.fam0)))

    if(!inherits(out.boot,"try-error")){
      pos.boot=c(pos.boot,time.sim)
      SE.list=c(SE.list,list(out.boot$SE))
      vtemp.list=c(vtemp.list,list(out.boot$vtemp))
    }
  }
}
if(Boostrap){
  est.list=est.list[pos.boot]
  datasim.list=datasim.list[pos.boot]
}


true.par = matrix(datasim$true.par[,paste(tau)],
                  nr=nrow(est.list[[1]]),nc=ncol(est.list[[1]]))

crqMI.shrink.sum <-
  function(est.list,SE.list,vtemp.list,datasim,print.tau,true.par,imp){
    valid.index1=sapply(1:length(est.list),
                        function(x)length(which(
                          is.na(est.list[[x]][,which(colnames(est.list[[1]])%in%
                                                       paste0(c("trueV","CC","naive","MI"),".tau=",max(print.tau)))])))==0)
    valid.index2=sapply(1:length(SE.list),
                        function(x)length(which(
                          is.na(SE.list[[x]][,which(colnames(SE.list[[1]])%in%
                                                      paste0(c("CC","MI"),".tau=",max(print.tau)))])))==0)

    valid.index=which(valid.index1&valid.index2)

    est.list=est.list[valid.index]
    SE.list=SE.list[valid.index]

    vtemp.pos=which(colnames(SE.list[[1]])%in%
                      paste0(c("CC","MI"),".tau=",rep(print.tau,each=2)))
    vtemp.pos=c(sapply(1:length(vtemp.pos),function(pos){
      (nrow(SE.list[[1]])* (vtemp.pos[pos]-1)+1):(nrow(SE.list[[1]])*vtemp.pos[pos])}))

    vtemp.list=vtemp.list[valid.index]
    cov.list= lapply(1:length(vtemp.list), function(x){cov(vtemp.list[[x]][,vtemp.pos])})

    cat("remain sim",length(est.list),".\n")

    est = Reduce("+",est.list)/length(est.list)
    sd=sapply(1:ncol(est),
              function(method){
                apply(sapply(1:length(est.list),
                             FUN = function(sim){est.list[[sim]][,method]}),1,sd)
              })
    trueV=est[,which(colnames(est)%in%  paste0("trueV",".tau=",print.tau))]


    cov.dim=nrow(cov.list[[1]])/2
    var.est.cc=lapply(1:length(cov.list),function(x){
      matrix(diag(cov.list[[x]][1:cov.dim,1:cov.dim]+cov.list[[x]][(cov.dim+1):(2*cov.dim),(cov.dim+1):(2*cov.dim)]-2*
                    cov.list[[x]][1:cov.dim,(cov.dim+1):(2*cov.dim)]),byrow = F,ncol = length(print.tau))
    })


    var.est.cc=lapply(1:length(var.est.cc),function(x){
      var.est.cc[[x]]/(var.est.cc[[x]]+(est.list[[x]][,which(colnames(est.list[[1]])%in%
                                                               paste0("MI",".tau=",print.tau))]-
                                          est.list[[x]][,which(colnames(est.list[[1]])%in%
                                                                 paste0("CC",".tau=",print.tau))])^2)
    })
    shrink.list= lapply(1:length(est.list),function(x){
      est.list[[x]][,which(colnames(est.list[[1]])%in%
                             paste0("CC",".tau=",print.tau))]+
        var.est.cc[[x]]*(
          est.list[[x]][,which(colnames(est.list[[1]])%in%
                                 paste0("MI",".tau=",print.tau))]-
            est.list[[x]][,which(colnames(est.list[[1]])%in%
                                   paste0("CC",".tau=",print.tau))])
    })


    shrink = Reduce("+",shrink.list)/length(shrink.list)
    shrink.sd=sapply(1:ncol(shrink),
                     function(method){
                       apply(sapply(1:length(shrink.list),
                                    FUN = function(sim){shrink.list[[sim]][,method]}),1,sd)
                     })

    SE.shrink.list= lapply(1:length(var.est.cc),function(x){
      sqrt(diag(cbind(diag(1- c(var.est.cc[[x]])),diag(c(var.est.cc[[x]])))%*%
                  cov.list[[x]]%*%t(cbind(diag(1- c(var.est.cc[[x]])),diag(c(var.est.cc[[x]]))))))
    })
    temp.SE = Reduce("+",SE.shrink.list)/length(SE.shrink.list)
    shrink.se=t(matrix(temp.SE, byrow=F, nrow=nrow(SE.list[[1]])))
    rownames(shrink.se)=paste0("MI.tau=",print.tau)


    true.par=true.par[,which(colnames(est.list[[1]])%in% paste0("CC",".tau=",print.tau))]
    shrink.bias=shrink-true.par
    colnames(shrink.sd)=colnames(shrink.list[[1]])


    trueV.bias=trueV-true.par
    trueV.sd=sd[,which(colnames(est)%in%  paste0("trueV",".tau=",print.tau))]

    rownames(shrink.sd)=rownames(shrink.bias)=
      c("beta0",paste0("alpha",1:ncol(datasim$obs.data$Z)),paste0("beta",1:ncol(datasim$obs.data$X)))
    rownames(trueV.sd)=rownames(trueV.bias)=
      c("beta0",paste0("alpha",1:ncol(datasim$obs.data$Z)),paste0("beta",1:ncol(datasim$obs.data$X)))




    bias2=cbind(trueV.bias,shrink.bias)
    sd2=cbind(trueV.sd,shrink.sd)
    colnames(sd2)=colnames(bias2)


    rownames(sd2)=rownames(bias2)=
      c("beta0",paste0("alpha",1:ncol(datasim$obs.data$Z)),paste0("beta",1:ncol(datasim$obs.data$X)))


    mse2 = bias2^2+sd2^2

    bias2=t(subset(bias2,select =paste0(c("CC"),".tau=",print.tau)))
    sd2=t(subset(sd2,select =paste0(c("CC"),".tau=",print.tau)))
    mse2=t(subset(mse2,select =paste0(c("trueV","CC"),".tau=",rep(print.tau,each=2))))
    RE= matrix(NA,nr=nrow(mse2),nc=ncol(mse2))
    for(k in 1:length(print.tau)){
      trueVpos=which(substring(rownames(mse2),first = 1,last=5)=="trueV")
      RE[trueVpos[k]+(1:(length(unique(substring(rownames(mse2),first = 1,last=5)))-1)),]=
        matrix(mse2[trueVpos[k],],nc=ncol(mse2),
               nr=(length(unique(substring(rownames(mse2),first = 1,last=5)))-1),byrow = T)/
        mse2[trueVpos[k]+(1:(length(unique(substring(rownames(mse2),first = 1,last=5)))-1)),]
    }
    RE=round(RE*100)
    RE[substring(rownames(bias2),first = 1,last=5)=="trueV",]=NA

    RE=na.omit(RE)

    sum.re=rbind(bias2[1,],sd2[1,], shrink.se[1,],RE[1,])
    for(k in 2:nrow(bias2)){
      sum.re=rbind(sum.re,bias2[k,],sd2[k,], shrink.se[k,],RE[k,])
    }
    rownames(sum.re)=c()
    sum.re0=c()
    for(k in 1:length(print.tau)){
      sum.re0=cbind(sum.re0,sum.re[(k-1)*(nrow(sum.re)/length(print.tau))+1:(nrow(sum.re)/length(print.tau)),],NA)
    }

    sum.re=sum.re0[,-ncol(sum.re0)]
    sum.re=data.frame(cbind(NA,NA,sum.re))
    sum.re[,2]=rep(c("bias","SD","SE","RE"),nrow(bias2)/length(print.tau))


    sum.re[,-(1:2)]=round(sum.re[,-(1:2)],3)
    sum.re[1,1]=paste0("MI-",imp,"*")
    #sum.re[is.na(sum.re)]=""
    sum.re=data.frame(sum.re)


    colnames(sum.re)[1]=imp

    return(sum.re)
  }
crqMI.summary <-
  function(est.list,SE.list=NULL,datasim,tau,print.tau,true.par,CR,imp){


    valid.index1=sapply(1:length(est.list),
                        function(x)length(which(
                          is.na(est.list[[x]][,which(colnames(est.list[[1]])%in%
                                                       paste0(c("trueV","CC","naive","MI"),".tau=",max(print.tau)))])))==0)
    if(!is.null(SE.list)){
      valid.index2=sapply(1:length(SE.list),
                          function(x)length(which(
                            is.na(SE.list[[x]][,which(colnames(SE.list[[1]])%in%
                                                        paste0(c("MI"),".tau=",max(print.tau)))])))==0)#"CC",
      valid.index=which(valid.index1&valid.index2)
    }else{
      valid.index=which(valid.index1)
    }


    est.list=est.list[valid.index]

    est = Reduce("+",est.list)/length(est.list)

    cat("remain sim",length(est.list),".\n")




    bias=est-true.par
    sd=sapply(1:ncol(est),
              function(method){
                apply(sapply(1:length(est.list),
                             FUN = function(sim){est.list[[sim]][,method]}),1,sd)
              })
    colnames(sd)=colnames(est.list[[1]])

    rownames(sd)=rownames(bias)=rownames(est)=c("beta0",paste0("alpha",
                                                               1:ncol(datasim$obs.data$Z)),
                                                paste0("beta",1:ncol(datasim$obs.data$X)))


    mse = bias^2+sd^2

    bias2=t(subset(bias,select =paste0(c("trueV","CC","naive","MI"),".tau=",rep(print.tau,each=4))))
    sd2=t(subset(sd,select =paste0(c("trueV","CC","naive","MI"),".tau=",rep(print.tau,each=4))))
    mse2=t(subset(mse,select =paste0(c("trueV","CC","naive","MI"),".tau=",rep(print.tau,each=4))))
    RE= matrix(NA,nr=nrow(bias2),nc=ncol(bias2))
    for(k in 1:length(print.tau)){
      trueVpos=which(substring(rownames(bias2),first = 1,last=5)=="trueV")
      RE[trueVpos[k]+(1:(length(unique(substring(rownames(bias2),first = 1,last=5)))-1)),]=
        matrix(mse2[trueVpos[k],],nc=ncol(bias2),
               nr=(length(unique(substring(rownames(bias2),first = 1,last=5)))-1),byrow = T)/
        mse2[trueVpos[k]+(1:(length(unique(substring(rownames(bias2),first = 1,last=5)))-1)),]
    }
    RE=RE*100
    RE[substring(rownames(bias2),first = 1,last=5)=="trueV",]=NA

    sum.re=rbind(bias2[1,],sd2[1,],RE[1,])
    for(k in 2:nrow(bias2)){
      sum.re=rbind(sum.re,bias2[k,],sd2[k,],RE[k,])
    }
    rownames(sum.re)=c()

    sum.re0=c()
    for(k in 1:length(print.tau)){
      sum.re0=cbind(sum.re0,sum.re[(k-1)*(nrow(sum.re)/length(print.tau))+1:(nrow(sum.re)/length(print.tau)),],NA)
    }

    sum.re=sum.re0[,-ncol(sum.re0)]


    sum.re=data.frame(cbind(NA,NA,sum.re))

    sum.re[,2]=rep(c("bias","SD","RE"),nrow(bias2)/length(print.tau))
    metd.sum.re=substring(rownames(bias2[1:(nrow(bias2)/length(print.tau)),]),first = 1,last=9)

    metd.sum.re[metd.sum.re=="CC.tau=0."]="CC"
    metd.sum.re[metd.sum.re=="MI.tau=0."]=paste0("MI-",imp)
    metd.sum.re[metd.sum.re=="trueV.tau"]="full"
    metd.sum.re[metd.sum.re=="naive.tau"]="fill-d"
    sum.re[sum.re[,2]=="bias",1]=metd.sum.re

    if(!is.null(SE.list)){
      SE.list=SE.list[sapply(1:length(SE.list),
                             function(x)length(which(
                               is.na(SE.list[[x]][,which(colnames(SE.list[[1]])%in%
                                                           paste0(c("MI"),".tau=",0.5))])))==0)]

      temp.SE = Reduce("+",SE.list)/length(SE.list)
      temp.SE=t(subset(temp.SE,select =paste0("MI.tau=",print.tau)))

      sum.re.se=c()
      for(k in 1:length(print.tau)){
        sum.re.se=c(sum.re.se,temp.SE[k,],NA)
      }
      sum.re.se=sum.re.se[-length(sum.re.se)]
      sum.re=rbind(sum.re,rep(NA,length(sum.re.se)+4))
      sum.re[nrow(sum.re),2]="SE"
      sum.re[nrow(sum.re),3:(length(sum.re.se)+2)]=sum.re.se
      sum.re=rbind(sum.re[-(nrow(sum.re)-1),],sum.re[(nrow(sum.re)-1),])
    }

    sum.re[sum.re[,2]=="RE",-(1:2)]=round(sum.re[sum.re[,2]=="RE",-(1:2)])
    sum.re[sum.re[,2]!="RE",-(1:2)]=round(sum.re[sum.re[,2]!="RE",-(1:2)],3)

    #sum.re[is.na(sum.re)]=""
    sum.re=data.frame(sum.re)
    rownames(sum.re)=c()

    colnames(sum.re)[1]=imp

    return(sum.re)

  }

if(!Boostrap){
  out.sum=crqMI.summary(est.list,SE.list=NULL,datasim,tau,print.tau=c(0.3,0.5),
                        true.par,imp=imp)
  print(out.sum)
}else{
  out.sum=crqMI.summary(est.list,SE.list,datasim,tau,print.tau= c(0.3,0.5),
                        true.par,imp=imp)
  out.shrink=crqMI.shrink.sum(est.list,SE.list,vtemp.list,datasim,
                              print.tau= c(0.3,0.5),true.par,imp=imp)
  print(rbind(out.sum,out.shrink))
}
